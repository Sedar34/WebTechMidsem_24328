package rw.TennisClub.TennisReservationSystem.model;

public enum Role {
    ROLE_USER,
    ROLE_SELLER,
    ROLE_ADMIN
}

